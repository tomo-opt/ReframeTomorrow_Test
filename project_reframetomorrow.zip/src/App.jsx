import React, { useState } from 'react';
import ImageGallery from './components/ImageGallery';
import DonationInput from './components/DonationInput';
import ImageTransformation from './components/ImageTransformation';
import Header from './components/Header';

const App = () => {
  const [selectedImage, setSelectedImage] = useState(null);
  const [donationAmount, setDonationAmount] = useState(0);
  const [transformedImage, setTransformedImage] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleImageSelect = (image) => {
    setSelectedImage(image);
    setTransformedImage(null);
  };

  const getTransformationPrompt = (imageTitle, amount) => {
    const getImpactLevel = () => {
      if (amount >= 5000) return 'complete';
      if (amount >= 500) return 'moderate';
      return 'basic';
    };

    const impact = getImpactLevel();
    const basePrompt = `Transform this poverty scene showing ${imageTitle.toLowerCase()}. Add:`;
    
    switch(imageTitle) {
      case "Shelter Crisis":
        return `${basePrompt} ${
          impact === 'basic' ? 'emergency tents, basic supplies, temporary shade structures' :
          impact === 'moderate' ? 'simple wooden shelters, communal cooking area, basic sanitation' :
          'simple permanent housing, community center, basic infrastructure'
        }. Style: documentary photography, natural lighting`;
      case "Water Access":
        return `${basePrompt} ${
          impact === 'basic' ? 'water containers, basic filtration, temporary water station' :
          impact === 'moderate' ? 'manual water pump, simple plumbing, water storage tanks' :
          'water distribution system, multiple access points, purification facility'
        }. Style: documentary photography, bright daytime`;
      case "Education Need":
        return `${basePrompt} ${
          impact === 'basic' ? 'portable blackboard, basic supplies, temporary learning space' :
          impact === 'moderate' ? 'simple classroom structure, desks, teaching materials' :
          'proper school building, multiple classrooms, learning facilities'
        }. Style: documentary photography`;
      case "Medical Support":
        return `${basePrompt} ${
          impact === 'basic' ? 'first aid supplies, basic medical kit, temporary medical tent' :
          impact === 'moderate' ? 'mobile clinic setup, basic medical equipment, treatment area' :
          'permanent clinic structure, medical facilities, patient care areas'
        }. Style: documentary photography`;
      default:
        return `${basePrompt} ${
          impact === 'basic' ? 'basic emergency supplies and temporary structures' :
          impact === 'moderate' ? 'simple permanent structures and basic facilities' :
          'community facilities and infrastructure improvements'
        }. Style: documentary photography`;
    }
  };

  const handleDonationSubmit = async (amount) => {
    setLoading(true);
    setDonationAmount(amount);
    
    try {
      const response = await fetch('https://api-hub-579483274893.us-central1.run.app/v1/run', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${import.meta.env.VITE_API_KEY}`
        },
        body: JSON.stringify({
          model: "replicate/black-forest-labs/flux-schnell",
          inputs: {
            prompt: getTransformationPrompt(selectedImage.title, amount),
            go_fast: true,
            num_outputs: 1,
            aspect_ratio: "4:3"
          }
        })
      });

      const data = await response.json();
      setTransformedImage(data[0]);
    } catch (error) {
      console.error('Error generating image:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        {!selectedImage ? (
          <ImageGallery onSelect={handleImageSelect} />
        ) : (
          <div className="space-y-8">
            <DonationInput onSubmit={handleDonationSubmit} loading={loading} />
            <ImageTransformation 
              originalImage={selectedImage}
              transformedImage={transformedImage}
              donationAmount={donationAmount}
              loading={loading}
            />
          </div>
        )}
      </main>
    </div>
  );
};

export default App;