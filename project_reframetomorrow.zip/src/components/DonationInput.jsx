import React, { useState } from 'react';

const DonationInput = ({ onSubmit, loading }) => {
  const [amount, setAmount] = useState('500');

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(Number(amount));
  };

  const getTierClass = (threshold) => {
    return `h-2 rounded-full transition-all duration-300 ${
      Number(amount) >= threshold ? 'bg-gradient-to-r from-primary to-secondary' : 'bg-gray-200'
    }`;
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
      <div className="p-8">
        <div className="mb-6 space-y-2">
          <div className="flex justify-between text-sm font-medium">
            <span>Basic Aid</span>
            <span>Infrastructure</span>
            <span>Community</span>
          </div>
          <div className="grid grid-cols-3 gap-1">
            <div className={getTierClass(50)}></div>
            <div className={getTierClass(500)}></div>
            <div className={getTierClass(5000)}></div>
          </div>
        </div>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <div className="mt-1 relative rounded-xl shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none">
                <span className="text-gray-500 text-xl">$</span>
              </div>
              <input
                type="number"
                name="amount"
                id="amount"
                min="1"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="block w-full pl-12 pr-12 py-4 sm:text-lg border-2 border-gray-200 rounded-xl focus:ring-primary focus:border-primary transition-colors duration-200"
                placeholder="Enter amount"
              />
            </div>
            <div className="mt-2 flex justify-between text-sm text-gray-500">
              <span>Basic: $50+</span>
              <span>Infrastructure: $500+</span>
              <span>Community: $5000+</span>
            </div>
          </div>
          <button
            type="submit"
            disabled={loading}
            className={`w-full flex justify-center py-4 px-6 border border-transparent rounded-xl text-lg font-semibold text-white hover-scale ${
              loading 
                ? 'bg-gray-400 cursor-not-allowed' 
                : 'gradient-bg hover:opacity-90'
            }`}
          >
            {loading ? (
              <div className="flex items-center space-x-2">
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
                <span>Processing...</span>
              </div>
            ) : (
              'Visualize Impact'
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default DonationInput;