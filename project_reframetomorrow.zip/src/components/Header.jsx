import React from 'react';

const Header = () => {
  return (
    <header className="relative overflow-hidden">
      <div className="absolute inset-0 gradient-bg animate-gradient opacity-90"></div>
      <div className="relative max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-extrabold text-white text-center mb-4 tracking-tight">
          Visualizing Real Impact
        </h1>
        <p className="text-xl text-white text-center font-medium opacity-90">
          See How Your Support Creates Meaningful Change
        </p>
      </div>
    </header>
  );
};

export default Header;