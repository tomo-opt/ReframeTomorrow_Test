import React from 'react';

const images = [
  {
    id: 1,
    url: "https://images.unsplash.com/photo-1523737000522-87c15d8efcc4",
    title: "Shelter Crisis",
    description: "Individual seeking shelter in makeshift conditions on urban streets"
  },
  {
    id: 2,
    url: "https://images.unsplash.com/photo-1622196464576-446a4a65b63c",
    title: "Basic Needs",
    description: "Person resting near urban infrastructure without proper shelter"
  },
  {
    id: 3,
    url: "https://images.unsplash.com/photo-1532600810905-98ad34c90e6c",
    title: "Urban Poverty",
    description: "Narrow alleyway showing challenging living conditions"
  },
  {
    id: 4,
    url: "https://images.unsplash.com/photo-1608342381036-15657da6bf58",
    title: "Winter Hardship",
    description: "Person facing harsh winter conditions without adequate shelter"
  }
];

const ImageGallery = ({ onSelect }) => {
  return (
    <div className="py-8">
      <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-4">
        {images.map((image) => (
          <div
            key={image.id}
            className="hover-scale cursor-pointer group"
            onClick={() => onSelect(image)}
          >
            <div className="relative aspect-[4/3] rounded-xl overflow-hidden shadow-lg">
              <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black opacity-50 group-hover:opacity-70 transition-opacity duration-300"></div>
              <img
                src={image.url}
                alt={image.title}
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
              />
              <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
                <h3 className="text-lg font-bold mb-1">{image.title}</h3>
                <p className="text-sm opacity-90">
                  {image.description}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ImageGallery;