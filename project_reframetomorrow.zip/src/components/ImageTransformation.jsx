import React from 'react';

const ImageTransformation = ({ originalImage, transformedImage, donationAmount, loading }) => {
  if (!originalImage) return null;

  const getTransformationStage = () => {
    if (donationAmount >= 5000) return 'Community Development';
    if (donationAmount >= 500) return 'Infrastructure Support';
    if (donationAmount >= 50) return 'Basic Emergency Aid';
    return 'Current Situation';
  };

  const getTransformationDescription = () => {
    if (donationAmount >= 5000) {
      return 'Long-term community development with permanent structures and facilities';
    } else if (donationAmount >= 500) {
      return 'Semi-permanent structures and basic infrastructure improvements';
    } else if (donationAmount >= 50) {
      return 'Immediate relief with temporary shelters and basic supplies';
    }
    return 'Area requiring humanitarian assistance';
  };

  const getImpactDetails = () => {
    if (donationAmount >= 5000) {
      return 'Can support construction of simple permanent buildings and community facilities';
    } else if (donationAmount >= 500) {
      return 'Can provide basic infrastructure like water pumps or simple shelters';
    } else if (donationAmount >= 50) {
      return 'Can supply emergency tents, food, and basic necessities';
    }
    return 'Select a donation amount to see potential impact';
  };

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-4">
          <div className="relative aspect-video rounded-2xl overflow-hidden shadow-xl bg-gray-100">
            <img
              src={originalImage.url}
              alt="Current situation"
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/70 to-transparent">
              <h3 className="text-white font-semibold">Current Situation</h3>
              <p className="text-white/90 text-sm">{originalImage.description}</p>
            </div>
          </div>
        </div>
        
        <div className="space-y-4">
          <div className="relative aspect-video rounded-2xl overflow-hidden shadow-xl bg-gray-100">
            {loading ? (
              <div className="absolute inset-0 flex items-center justify-center bg-gray-100">
                <div className="relative">
                  <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-primary"></div>
                </div>
              </div>
            ) : transformedImage ? (
              <>
                <img
                  src={transformedImage}
                  alt="Transformed scene"
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/70 to-transparent">
                  <h3 className="text-white font-semibold">{getTransformationStage()}</h3>
                  <p className="text-white/90 text-sm">{getTransformationDescription()}</p>
                </div>
              </>
            ) : (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-lg text-gray-500 font-medium">
                  Enter donation to visualize impact
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {transformedImage && (
        <div className="bg-white rounded-xl p-6 shadow-lg space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold text-gray-800">{getTransformationStage()}</h3>
            <span className="px-4 py-2 bg-primary/10 text-primary rounded-full font-medium">
              ${donationAmount.toLocaleString()}
            </span>
          </div>
          <p className="text-gray-600">{getTransformationDescription()}</p>
          <p className="text-sm text-gray-500">{getImpactDetails()}</p>
          <div className="flex justify-end space-x-4">
            <button
              onClick={() => {
                const link = document.createElement('a');
                link.href = transformedImage;
                link.download = 'transformed-scene.jpg';
                link.click();
              }}
              className="px-6 py-3 rounded-xl bg-white border-2 border-gray-200 text-gray-700 hover:bg-gray-50 hover-scale"
            >
              Download
            </button>
            <button
              onClick={() => {
                if (navigator.share) {
                  navigator.share({
                    title: 'Visualizing Aid Impact',
                    text: `See how $${donationAmount.toLocaleString()} can make a difference`,
                    url: window.location.href,
                  });
                }
              }}
              className="px-6 py-3 rounded-xl text-white gradient-bg hover:opacity-90 hover-scale"
            >
              Share
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ImageTransformation;